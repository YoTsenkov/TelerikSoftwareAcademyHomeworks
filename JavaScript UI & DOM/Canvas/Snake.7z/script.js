/**
 * Created by Dani on 6/5/2014.
 */
var canvas = document.getElementById('canvas'),
    ctx = canvas.getContext('2d');
const WINDOW_WIDTH = 800,
    WINDOW_HEIGHT = 600;

document.body.style.backgroundColor = '#000';
canvas.style.border = '1px solid white';


startNewGame(ctx);



