describe('#sum', function () {
    it('when empty array, expect to return 0', function () {
        var actual = 'number';
        expect(actual).to.equal(getNumber());
    });
});
